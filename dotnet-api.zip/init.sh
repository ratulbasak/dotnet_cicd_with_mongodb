#!/bin/bash

rm -r dotnet-api.zip
echo "Zipping the project CodeBase"
zip -r dotnet-api.zip ./*
